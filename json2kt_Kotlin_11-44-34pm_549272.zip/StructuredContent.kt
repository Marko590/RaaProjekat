package com.example.example

import com.google.gson.annotations.SerializedName


data class StructuredContent (

  @SerializedName("images"      ) var images      : ArrayList<String>      = arrayListOf(),
  @SerializedName("sections"    ) var sections    : ArrayList<Sections>    = arrayListOf(),
  @SerializedName("attribution" ) var attribution : ArrayList<Attribution> = arrayListOf()

)