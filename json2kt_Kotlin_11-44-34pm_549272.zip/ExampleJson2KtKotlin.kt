package com.example.example

import com.google.gson.annotations.SerializedName


data class ExampleJson2KtKotlin (

  @SerializedName("results"       ) var results      : ArrayList<Results> = arrayListOf(),
  @SerializedName("more"          ) var more         : Boolean?           = null,
  @SerializedName("is_deprecated" ) var isDeprecated : String?            = null

)