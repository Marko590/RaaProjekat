package com.example.example

import com.google.gson.annotations.SerializedName


data class Sections (

  @SerializedName("body"        ) var body        : String?           = null,
  @SerializedName("title"       ) var title       : String?           = null,
  @SerializedName("labels"      ) var labels      : ArrayList<String> = arrayListOf(),
  @SerializedName("topics"      ) var topics      : ArrayList<String> = arrayListOf(),
  @SerializedName("summary"     ) var summary     : String?           = null,
  @SerializedName("sections"    ) var sections    : ArrayList<String> = arrayListOf(),
  @SerializedName("object_id"   ) var objectId    : String?           = null,
  @SerializedName("body_images" ) var bodyImages  : ArrayList<String> = arrayListOf(),
  @SerializedName("coordinates" ) var coordinates : String?           = null,
  @SerializedName("object_type" ) var objectType  : String?           = null

)