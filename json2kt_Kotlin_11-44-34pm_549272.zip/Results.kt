package com.example.example

import com.google.gson.annotations.SerializedName


data class Results (

  @SerializedName("id"                               ) var id                            : String?            = null,
  @SerializedName("name_language_info"               ) var nameLanguageInfo              : String?            = null,
  @SerializedName("name"                             ) var name                          : String?            = null,
  @SerializedName("score"                            ) var score                         : Double?            = null,
  @SerializedName("structured_content_language_info" ) var structuredContentLanguageInfo : String?            = null,
  @SerializedName("structured_content"               ) var structuredContent             : StructuredContent? = StructuredContent(),
  @SerializedName("snippet_language_info"            ) var snippetLanguageInfo           : String?            = null,
  @SerializedName("snippet"                          ) var snippet                       : String?            = null

)